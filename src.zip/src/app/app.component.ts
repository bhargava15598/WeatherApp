import { Component } from '@angular/core';
import { AppService } from './app.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app works!';
  hide = false;

  constructor(public appService: AppService) {

  }
  x :string
  imgSrc
  imgSrc2
  imgSrc3
  imgSrc4
  imgSrc5
  imgSrc6
  imgSrc7
  imgSrc8
  imgSrc9
  temp 
  temperature
  result = {}	
  city_name
  buttonClick() {
  	this.hide = true;
  	this.appService.getData('chennai');
  }

  a(){
  	this.x = document.forms["form1"]["city"].value;
  	//console.log(this.x);
  	if(this.x == "") {
  		document.getElementById("home1").style.display = 'none';
  		document.getElementById("error1").style.display = '';
  	}
  	else{
  		this.appService.getData(this.x).subscribe(
  				response =>{
  					response = response.json();
  					this.result = response;
  					//console.log(this.city_name);
  					this.temp = +this.result["main"]["temp"];
  					console.log(this.temp);
  					document.getElementById("temperature").innerHTML = String(Math.round((this.temp - 273.15)*100)/100);
  					document.getElementById("cityname").innerHTML = this.result["name"];
  					document.getElementById("weather1").innerHTML = this.result["weather"][0]["main"];
  					document.getElementById("home1").style.display = 'none';
  					document.getElementById("data1").style.display = '';
  					this.imgSrc = "http://openweathermap.org/img/w/" + this.result["weather"][0]["icon"] +".png";
  				}
  			);   			
  		}
  	}

  	a2(){
  	this.x = document.forms["form2"]["city2"].value;
  	//console.log(this.x);
  	if(this.x == "") {
  		document.getElementById("home2").style.display = 'none';
  		document.getElementById("error2").style.display = '';
  	}
  	else{
  		this.appService.getData(this.x).subscribe(
  				response =>{
  					response = response.json();
  					this.result = response;
  					this.temp = +this.result["main"]["temp"];
  					//console.log(this.city_name);
  					document.getElementById("temperature2").innerHTML =  String(Math.round((this.temp - 273.15)*100)/100);
  					document.getElementById("cityname2").innerHTML = this.result["name"];
  					document.getElementById("weather2").innerHTML = this.result["weather"][0]["main"];
  					document.getElementById("home2").style.display = 'none';
  					document.getElementById("data2").style.display = '';
  					this.imgSrc2 = "http://openweathermap.org/img/w/" + this.result["weather"][0]["icon"] +".png";
  				}
  			);   			
  		}
  	}

  	a3(){
  	this.x = document.forms["form3"]["city3"].value;
  	//console.log(this.x);
  	if(this.x == "") {
  		document.getElementById("home3").style.display = 'none';
  		document.getElementById("error3").style.display = '';
  	}
  	else{
  		this.appService.getData(this.x).subscribe(
  				response =>{
  					response = response.json();
  					this.result = response;
  					this.temp = +this.result["main"]["temp"];
  					//console.log(this.city_name);
  					document.getElementById("temperature3").innerHTML =  String(Math.round((this.temp - 273.15)*100)/100);
  					document.getElementById("cityname3").innerHTML = this.result["name"];
  					document.getElementById("weather3").innerHTML = this.result["weather"][0]["main"];
  					document.getElementById("home3").style.display = 'none';
  					document.getElementById("data3").style.display = '';
  					this.imgSrc3 = "http://openweathermap.org/img/w/" + this.result["weather"][0]["icon"] +".png";
  				}
  			);   			
  		}
  	}

  	a4(){
  	this.x = document.forms["form4"]["city4"].value;
  	//console.log(this.x);
  	if(this.x == "") {
  		document.getElementById("home4").style.display = 'none';
  		document.getElementById("error4").style.display = '';
  	}
  	else{
  		this.appService.getData(this.x).subscribe(
  				response =>{
  					response = response.json();
  					this.result = response;
  					this.temp = +this.result["main"]["temp"];
  					//console.log(this.city_name);
  					document.getElementById("temperature4").innerHTML =  String(Math.round((this.temp - 273.15)*100)/100);
  					document.getElementById("cityname4").innerHTML = this.result["name"];
  					document.getElementById("weather4").innerHTML = this.result["weather"][0]["main"];
  					document.getElementById("home4").style.display = 'none';
  					document.getElementById("data4").style.display = '';
  					this.imgSrc4 = "http://openweathermap.org/img/w/" + this.result["weather"][0]["icon"] +".png";
  				}
  			);   			
  		}
  	}

  	a5(){
  	this.x = document.forms["form5"]["city5"].value;
  	//console.log(this.x);
  	if(this.x == "") {
  		document.getElementById("home5").style.display = 'none';
  		document.getElementById("error5").style.display = '';
  	}
  	else{
  		this.appService.getData(this.x).subscribe(
  				response =>{
  					response = response.json();
  					this.result = response;
  					this.temp = +this.result["main"]["temp"];
  					//console.log(this.city_name);
  					document.getElementById("temperature5").innerHTML =  String(Math.round((this.temp - 273.15)*100)/100);
  					document.getElementById("cityname5").innerHTML = this.result["name"];
  					document.getElementById("weather5").innerHTML = this.result["weather"][0]["main"];
  					document.getElementById("home5").style.display = 'none';
  					document.getElementById("data5").style.display = '';
  					this.imgSrc5 = "http://openweathermap.org/img/w/" + this.result["weather"][0]["icon"] +".png";
  				}
  			);   			
  		}
  	}

  	a6(){
  	this.x = document.forms["form6"]["city6"].value;
  	//console.log(this.x);
  	if(this.x == "") {
  		document.getElementById("home6").style.display = 'none';
  		document.getElementById("error6").style.display = '';
  	}
  	else{
  		this.appService.getData(this.x).subscribe(
  				response =>{
  					response = response.json();
  					this.result = response;
  					this.temp = +this.result["main"]["temp"];
  					//console.log(this.city_name);
  					document.getElementById("temperature6").innerHTML =  String(Math.round((this.temp - 273.15)*100)/100);
  					document.getElementById("cityname6").innerHTML = this.result["name"];
  					document.getElementById("weather6").innerHTML = this.result["weather"][0]["main"];
  					document.getElementById("home6").style.display = 'none';
  					document.getElementById("data6").style.display = '';
  					this.imgSrc6 = "http://openweathermap.org/img/w/" + this.result["weather"][0]["icon"] +".png";
  				}
  			);   			
  		}
  	}

  	a7(){
  	this.x = document.forms["form7"]["city7"].value;
  	//console.log(this.x);
  	if(this.x == "") {
  		document.getElementById("home7").style.display = 'none';
  		document.getElementById("error7").style.display = '';
  	}
  	else{
  		this.appService.getData(this.x).subscribe(
  				response =>{
  					response = response.json();
  					this.result = response;
  					this.temp = +this.result["main"]["temp"];
  					//console.log(this.city_name);
  					document.getElementById("temperature7").innerHTML =  String(Math.round((this.temp - 273.15)*100)/100);
  					document.getElementById("cityname7").innerHTML = this.result["name"];
  					document.getElementById("weather7").innerHTML = this.result["weather"][0]["main"];
  					document.getElementById("home7").style.display = 'none';
  					document.getElementById("data7").style.display = '';
  					this.imgSrc7 = "http://openweathermap.org/img/w/" + this.result["weather"][0]["icon"] +".png";
  				}
  			);   			
  		}
  	}

  	a8(){
  	this.x = document.forms["form8"]["city8"].value;
  	//console.log(this.x);
  	if(this.x == "") {
  		document.getElementById("home8").style.display = 'none';
  		document.getElementById("error8").style.display = '';
  	}
  	else{
  		this.appService.getData(this.x).subscribe(
  				response =>{
  					response = response.json();
  					this.result = response;
  					this.temp = +this.result["main"]["temp"];
  					//console.log(this.city_name);
  					document.getElementById("temperature8").innerHTML =  String(Math.round((this.temp - 273.15)*100)/100);
  					document.getElementById("cityname8").innerHTML = this.result["name"];
  					document.getElementById("weather8").innerHTML = this.result["weather"][0]["main"];
  					document.getElementById("home8").style.display = 'none';
  					document.getElementById("data8").style.display = '';
  					this.imgSrc8 = "http://openweathermap.org/img/w/" + this.result["weather"][0]["icon"] +".png";
  				}
  			);   			
  		}
  	}


  	a9(){
  	this.x = document.forms["form9"]["city9"].value;
  	//console.log(this.x);
  	if(this.x == "") {
  		document.getElementById("home9").style.display = 'none';
  		document.getElementById("error9").style.display = '';
  	}
  	else{
  		this.appService.getData(this.x).subscribe(
  				response =>{
  					response = response.json();
  					this.result = response;
  					this.temp = +this.result["main"]["temp"];
  					//console.log(this.city_name);
  					document.getElementById("temperature9").innerHTML =  String(Math.round((this.temp - 273.15)*100)/100);
  					document.getElementById("cityname9").innerHTML = this.result["name"];
  					document.getElementById("weather9").innerHTML = this.result["weather"][0]["main"];
  					document.getElementById("home9").style.display = 'none';
  					document.getElementById("data9").style.display = '';
  					this.imgSrc9 = "http://openweathermap.org/img/w/" + this.result["weather"][0]["icon"] +".png";
  				}
  			);   			
  		}
  	}

  b(){
  	document.getElementById("home1").style.display = '';
  	document.getElementById("error1").style.display = 'none';
  }

  c(){
  	document.getElementById("home1").style.display = '';
  	document.getElementById("data1").style.display = 'none';
  }

  b2(){
  	document.getElementById("home2").style.display = '';
  	document.getElementById("error2").style.display = 'none';
  }

  c2(){
  	document.getElementById("home2").style.display = '';
  	document.getElementById("data2").style.display = 'none';
  }

  b3(){
  	document.getElementById("home3").style.display = '';
  	document.getElementById("error3").style.display = 'none';
  }

  c3(){
  	document.getElementById("home3").style.display = '';
  	document.getElementById("data3").style.display = 'none';
  }

  b4(){
  	document.getElementById("home4").style.display = '';
  	document.getElementById("error4").style.display = 'none';
  }

  c4(){
  	document.getElementById("home4").style.display = '';
  	document.getElementById("data4").style.display = 'none';
  }

  b5(){
  	document.getElementById("home5").style.display = '';
  	document.getElementById("error5").style.display = 'none';
  }

  c5(){
  	document.getElementById("home5").style.display = '';
  	document.getElementById("data5").style.display = 'none';
  }

  b6(){
  	document.getElementById("home6").style.display = '';
  	document.getElementById("error6").style.display = 'none';
  }

  c6(){
  	document.getElementById("home6").style.display = '';
  	document.getElementById("data6").style.display = 'none';
  }

  b7(){
  	document.getElementById("home7").style.display = '';
  	document.getElementById("error7").style.display = 'none';
  }

  c7(){
  	document.getElementById("home7").style.display = '';
  	document.getElementById("data7").style.display = 'none';
  }

  b8(){
  	document.getElementById("home8").style.display = '';
  	document.getElementById("error8").style.display = 'none';
  }

  c8(){
  	document.getElementById("home8").style.display = '';
  	document.getElementById("data8").style.display = 'none';
  }

  b9(){
  	document.getElementById("home9").style.display = '';
  	document.getElementById("error9").style.display = 'none';
  }

  c9(){
  	document.getElementById("home9").style.display = '';
  	document.getElementById("data9").style.display = 'none';
  }
}
