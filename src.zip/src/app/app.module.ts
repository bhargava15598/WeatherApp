import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
import { AlertModule } from 'ng2-bootstrap';
import { AppService } from './app.service';
import { AppComponent } from './app.component';
import { SecondComponent } from './second.component';
import { RouterModule } from '@angular/router';

@NgModule({
  declarations: [
    AppComponent,
    SecondComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpModule,
    AlertModule.forRoot(),
    RouterModule
  ],
  exports: [
    SecondComponent
  ],
  providers: [AppService],
  bootstrap: [AppComponent]
})
export class AppModule { }
