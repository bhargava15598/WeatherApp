import { Component } from '@angular/core';

@Component({
  selector: 'second-root',
  template: `<h1>hey there</h1>`
})

export class SecondComponent {
}