import { Injectable,Inject } from '@angular/core';
import { Http } from '@angular/http';
//import { Router } from '@angular/router';

@Injectable()
export class AppService {
	result
	constructor(private http: Http) {

	}
	apiId = "&appid=08813ce1a7b7ed735a740c0b6d220e14"
	getData(name: string)	{
		// make http call, and get data
		return this.http.get("http://api.openweathermap.org/data/2.5/weather?q="+name+this.apiId);
	}
}